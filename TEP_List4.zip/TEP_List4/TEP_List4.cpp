// TEP_List4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "CInterface.h"

int main()
{
    CInterface interface;
    interface.run();
}

//1. zmienic CError
//*napisac klase ktora bedzie zapisywac do pliku
//*zmienic drzewo aby zmaiast retur null return CError dzialal na CResult i zwracal poprstu CResult jako return
//* 

//zajecia:
//# include "table.cpp" na koncu headera
//standardowo wszystko w headerze
//narasstajaco jeden plik o maksymalnej pojemnosci